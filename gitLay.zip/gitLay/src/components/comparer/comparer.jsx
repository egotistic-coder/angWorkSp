import React, { Component } from 'react';
import {
    Box,
    Button,
    Card,
    CardContent,
    TextField, Grid
} from '@material-ui/core';


export default class ComparerBar extends Component {
    render() {
        return (
            <div></div>
        )
    }
}

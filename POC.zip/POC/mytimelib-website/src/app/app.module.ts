import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {HeaderLibModule} from '@my-libcollection/header-lib';
import {ReUsableLibModule} from '@my-libcollection/re-usable-lib';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    ReUsableLibModule,
    HeaderLibModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

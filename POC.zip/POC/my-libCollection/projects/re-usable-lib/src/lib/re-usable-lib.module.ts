import { NgModule } from '@angular/core';
import { ReUsableLibComponent } from './re-usable-lib.component';



@NgModule({
  declarations: [ReUsableLibComponent],
  imports: [
  ],
  exports: [ReUsableLibComponent]
})
export class ReUsableLibModule { }

import React, { Component } from 'react'
import {
    Box,
    Button,
    Card,
    CardContent,
    Avatar,
    CardActions,
    Divider,
    Typography
  } from '@material-ui/core';
  

export default class ManagerProfile extends Component {
    render() {
        return (
            <Card>
    <CardContent>
      <Box
        sx={{
          alignItems: 'center',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        <Avatar
          src={this.props.user.avatar}
          sx={{
            height: 100,
            width: 100
          }}
        />
        <Typography color="textPrimary" gutterBottom variant="h3">
          {this.props.user.name}
        </Typography>
        <Typography color="textSecondary" variant="body1">
          {`${this.props.user.jobTitle}`}
        </Typography>
        <Typography color="textSecondary" variant="body1">
          {`Reportees : ${this.props.user.reporties}`}
        </Typography>
      </Box>
    </CardContent>
    <Divider />
    <CardActions>
      <Button color="primary" fullWidth variant="text">
        Direct Reportees and contacts
      </Button>
    </CardActions>
  </Card>
        )
    }
}



import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Helmet } from 'react-helmet';
import {
  Box,
  Container,
  Grid
} from '@material-ui/core';
import UserProfile from 'src/components/profile/userprofile.jsx';
import UserProfileDetails from 'src/components/profile/userprofile-details.jsx';

const userinfo = {
  avatar: '/static/images/avatars/avatar.jpg',
  city: 'Los Angeles',
  phone: '+91 1234567890',
  country: 'USA',
  jobTitle: 'Senior Developer',
  name: 'Katarina Smith',
  timezone: 'GTM-7', email: 'demo@test.io'
};

const userprofile= {
  firstName: 'Katarina',
  lastName: 'Smith',
  email: 'demo@test.io',
  phone: '',
  state: 'Alabama',
  country: 'USA'
};




class Profile extends Component {
  render() {
    return (
      <>
      <Helmet>
        <title>My Profile</title>
      </Helmet>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 3
        }}
      >
        <Container maxWidth="lg">
          <Grid
            container
            spacing={3}
          >
            <Grid
              item
              lg={4}
              md={6}
              xs={12}
            >
              <UserProfile user={userinfo}></UserProfile>
            </Grid>
            <Grid
              item
              lg={8}
              md={6}
              xs={12}
            >
              <UserProfileDetails user={userprofile}/>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </>
    );
  }
}


Profile.propTypes = {

};


export default Profile;

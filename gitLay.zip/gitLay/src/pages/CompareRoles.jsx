import React, { Component } from 'react';
import { Helmet } from 'react-helmet';
import {
  Box ,Container
} from '@material-ui/core';
import ComparerBar from 'src/components/comparer/comparer.jsx';
import users from 'src/mockdata/users';

const compareOptions =
{
  action: 'compare',
  placeholder: 'search user to compare'
};

class CompareRoles extends Component {
  render() {
    return (
      <>
      <Helmet>
      <title>Compare User Roles</title>
    </Helmet>
    <Box
      sx={{
        backgroundColor: 'background.default',
        minHeight: '100%',
        py: 3
      }}
    >
      <Container maxWidth={false}>
        <ComparerBar comparer={compareOptions} userlist={users}/>
        <Box sx={{ pt: 3 }}>
          
        </Box>
      </Container>
    </Box>
    </>
    );
  }
}

export default CompareRoles;

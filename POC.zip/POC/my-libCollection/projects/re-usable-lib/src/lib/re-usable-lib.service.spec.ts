import { TestBed } from '@angular/core/testing';

import { ReUsableLibService } from './re-usable-lib.service';

describe('ReUsableLibService', () => {
  let service: ReUsableLibService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReUsableLibService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

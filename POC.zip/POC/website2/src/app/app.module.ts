import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { MatSliderModule } from '@angular/material/slider';

import {MatTabsModule} from '@angular/material/tabs';

import {MatProgressBarModule} from '@angular/material/progress-bar';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {ReUsableLibModule} from 're-usable-lib';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MatSliderModule,
    MatTabsModule,
    MatProgressBarModule,
    ReUsableLibModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

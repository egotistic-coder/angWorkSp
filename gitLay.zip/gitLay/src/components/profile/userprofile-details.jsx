import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  Divider,
  Grid,
  TextField
} from '@material-ui/core';





class UserProfileDetails extends Component {
    
    render() {    

        return (
            <form
            autoComplete="off"
            noValidate
           
          >
            <Card>
              <CardHeader
                subheader="The information can't be edited"
                title="Profile"
              />
              {this.props.user.name}
              <Divider />
              <CardContent>
                <Grid
                  container
                  spacing={3}
                >
                  <Grid
                    item
                    md={6}
                    xs={12}
                  >
                    <TextField
                      fullWidth
                      helperText="Please specify the first name"
                      label="First name"
                      name="firstName"
                      
                      required
                      value={this.props.user.firstName}
                      variant="outlined"
                    />
                  </Grid>
                  <Grid
                    item
                    md={6}
                    xs={12}
                  >
                    <TextField
                      fullWidth
                      label="Last name"
                      name="lastName"                     
                      required
                      value={this.props.user.lastName}
                      variant="outlined"
                    />
                  </Grid>
                  <Grid
                    item
                    md={6}
                    xs={12}
                  >
                    <TextField
                      fullWidth
                      label="Email Address"
                      name="email"
                    
                      required
                      value={this.props.user.email}
                      variant="outlined"
                    />
                  </Grid>
                  <Grid
                    item
                    md={6}
                    xs={12}
                  >
                    <TextField
                      fullWidth
                      label="Phone Number"
                      name="phone"
                      
                      type="number"
                      value={this.props.user}
                      variant="outlined"
                    />
                  </Grid>
                  <Grid
                    item
                    md={6}
                    xs={12}
                  >
                    <TextField
                      fullWidth
                      label="Country"
                      name="country"
                      
                      required
                      value={this.props.user.country}
                      variant="outlined"
                    />
                  </Grid>
                  <Grid
                    item
                    md={6}
                    xs={12}
                  >
                    <TextField
                      fullWidth
                      label="State"
                      name="state"
                      
                      required
                      value={this.props.user.state}
                      variant="outlined"
                    />
                  </Grid>
                </Grid>
              </CardContent>              
            </Card>
          </form>
        )
    }
}
UserProfileDetails.propTypes = {
  
};


export default UserProfileDetails;

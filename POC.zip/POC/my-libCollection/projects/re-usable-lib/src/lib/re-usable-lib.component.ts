import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-ReUsable-Lib',
  template: `
    <p>
      re-usable-lib works!
    </p>
  `,
  styles: []
})
export class ReUsableLibComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

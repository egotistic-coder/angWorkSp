
import React, { Component } from 'react';
import { Helmet } from 'react-helmet';
import {
  Box,
  Container,
  Grid,
  Pagination
} from '@material-ui/core';
import ManagerProfile from 'src/components/profile/managerprofile'
import UserProfile from 'src/components/profile/userprofile.jsx';
import userslist from 'src/mockdata/users';

const user = {
  avatar: '/static/images/avatars/avatar_1.png',
  city: 'Los Angeles',
  phone: '+91 1234567890',
  country: 'USA',
  jobTitle: 'Project Manager',
  name: 'Ekaterina Tankova',
  timezone: 'GTM-7',
  reportsTo: 'Project Manager',
  reporties: 5
};


class ManagerView extends Component {
  render() {
    return (
      <>
      <Helmet>
        <title>Manager View </title>
      </Helmet>
      <Box
        sx={{
          backgroundColor: 'background.default',
          minHeight: '100%',
          py: 3
        }}
      >
        <Container maxWidth={false}>
        <ManagerProfile user={user}/>
          <Box sx={{ pt: 3 }}>
            <Grid
              container
              spacing={3}
            >
              {userslist.map((currentuser) => (
                <Grid
                  item
                  key={currentuser.email}
                  lg={4}
                  md={6}
                  xs={12}
                >
                  <UserProfile user={currentuser} />
                </Grid>
              ))}
            </Grid>
          </Box>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              pt: 3
            }}
          >
            <Pagination
              color="primary"
              count={3}
              size="small"
            />
          </Box>
        </Container>
      </Box>
    </>
    );
  }
}

export default ManagerView;

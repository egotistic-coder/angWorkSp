import React, { Component } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Divider,
  Typography
} from '@material-ui/core';

class UserProfile extends Component {
    render() {
        return (
            <Card >
                <CardContent>
                    <Box
                        sx={{
                            display: 'flex',
                            flexDirection: 'column'
                        }}
                    >
                        <Avatar
                            src={this.props.user.avatarUrl}
                            sx={{
                                height: 100,
                                width: 100
                            }}
                        />
                        <Typography color="textPrimary" gutterBottom variant="h3">
                            {this.props.user.name}
                        </Typography>
                        <Typography color="textSecondary" variant="body1">
                         address :   {`${this.props.user.city} ${this.props.user.country}`}
                        </Typography>
                        <Typography color="textSecondary" variant="body1">
                         contact :  {`${this.props.user.phone}`}
                        </Typography>
                        <Typography color="textSecondary" variant="body1">
                         email :   {`${this.props.user.email}`}
                        </Typography>
                    </Box>
                </CardContent>
                <Divider />
                
            </Card>
        );
    }
}

UserProfile.propTypes = {
  
};


export default UserProfile;

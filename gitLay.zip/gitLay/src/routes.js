import { Navigate } from "react-router-dom";
import DashboardLayout from "src/layouts/dashboard/DashboardLayout.jsx";
import Profile from "src/pages/Profile.jsx";
import UserList from "src/pages/UserList.jsx";
import Dashboard from "src/pages/Dashboard.jsx";
import ManagerView from "src/pages/ManagerView.jsx";
import CompareRoles from "src/pages/CompareRoles.jsx";

const routes = [
  {
    path: "/",
    element: <DashboardLayout />,
    children: [
      { exact: "/account", path: "account", element: <Profile /> },
      { exact: "/users", path: "users", element: <UserList /> },     
      { exact: "/dashboard", path: "dashboard", element: <Dashboard /> },
      { exact: "/manager", path: "manager", element: <ManagerView /> },
      { exact: "/roles", path: "roles", element: <CompareRoles /> },
      { path: "*", element: <Navigate to="/404" /> },
    ],
  },
];

export default routes;

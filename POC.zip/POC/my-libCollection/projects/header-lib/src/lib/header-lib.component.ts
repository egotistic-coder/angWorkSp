import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-header-lib',
  template: `
    <p>
      header-lib works!
    </p>
  `,
  styles: []
})
export class HeaderLibComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

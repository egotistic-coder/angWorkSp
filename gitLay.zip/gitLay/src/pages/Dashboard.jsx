import React, { Component } from 'react';
import { Helmet } from 'react-helmet';
import {
  Box
} from '@material-ui/core';

class Dashboard extends Component {
  render() {
    return (
      <>
        <Helmet>
          <title>My Dashboard </title>
        </Helmet>
        <Box
          sx={{
            backgroundColor: 'background.default',
            minHeight: '100%',
            py: 3
          }}
        >
          {


          }
        </Box>
      </>
    );
  }
}

export default Dashboard;

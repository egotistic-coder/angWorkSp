import { Helmet } from 'react-helmet';
import { Box, Container } from '@material-ui/core';
import UserListview from 'src/components/profile/userlistview.jsx';
import SearchBar from 'src/components/search/searchbar.jsx';
import user from 'src/mockdata/users';

const seacrchOptions =
{
  buttonTitle: 'search',
  placeholder: 'search users'
};

const UserList = () => (
  <>
    <Helmet>
      <title>Active Directory Users</title>
    </Helmet>
    <Box
      sx={{
        backgroundColor: 'background.default',
        minHeight: '100%',
        py: 3
      }}
    >
      <Container maxWidth={false}>
        <SearchBar search={seacrchOptions}/>
        <Box sx={{ pt: 3 }}>
          <UserListview customers={user} />
        </Box>
      </Container>
    </Box>
  </>
);

export default UserList;
